package com.example.datagenerator;

import lombok.Data;

import java.util.List;

@Data
public class VehicleRawDataWrapper {
    List<Vehicle> data;

    @Data
    public static class Vehicle {
        String id, vin, make, model, trim, body_style, exterior_color, engine, transmission, drive_type, fuel, vehicle_condition;
        Integer mpg_combined, year, mileage, price, mpg_city, mpg_highway;
        Dealer dealer;
        DealerLocation location;
        VehicleFeatureDetails details;
        List<String> badge_labels;
    }

    @Data
    public static class VehicleFeatureDetails{
        List<String> audio_and_navigation;
        List<String> safety_and_security;
        List<String> comfort_and_convenience;
        List<String> performance;
        List<String> other_car_features ;
    }

    public record Dealer(String name) {
    }

    record DealerLocation(String country, String state, String city, String zip, String address, Integer distance) {
    }

}
