package com.example.datagenerator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.StringUtils;

import javax.swing.text.html.Option;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@SpringBootApplication
public class App implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        VehicleRawDataWrapper vehicleRawDataWrapper = mapper.readValue(new File("vechile_data_75024.json"), new TypeReference<VehicleRawDataWrapper>() {
            @Override
            public int compareTo(TypeReference<VehicleRawDataWrapper> o) {
                return super.compareTo(o);
            }
        });

        List<NewVehicle> newVehicles = vehicleRawDataWrapper.getData()
                .stream().map(e -> {
                    NewVehicle newVehicle = new NewVehicle();
                    BeanUtils.copyProperties(e, newVehicle);
              //      newVehicle.setImageUrl("https://img.vast.com/apollo/"+e.id+"/1/640x-");
//                    newVehicle.setSpecifications(new ArrayList<>());
//                    newVehicle.setFeatures(new ArrayList<>());
//                    if (e.details != null) {
//                        newVehicle.getSpecifications().addAll(Optional.ofNullable(e.getDetails().getAudio_and_navigation()).orElse(new ArrayList<>()));
//                        newVehicle.getSpecifications().addAll(Optional.ofNullable(e.getDetails().getSafety_and_security()).orElse(new ArrayList<>()));
//                        newVehicle.getSpecifications().addAll(Optional.ofNullable(e.getDetails().getComfort_and_convenience()).orElse(new ArrayList<>()));
//                        newVehicle.getSpecifications().addAll(Optional.ofNullable(e.getDetails().getPerformance()).orElse(new ArrayList<>()));
//                        newVehicle.getFeatures().addAll(Optional.ofNullable(e.getDetails().getOther_car_features()).orElse(new ArrayList<>()));
//                    }
//                    newVehicle.getFeatures().addAll(Optional.of(e.badge_labels).orElse(new ArrayList<>()));
//                    newVehicle.setDealer(new NewVehicle.Dealer(e.getDealer().name(),
//                            e.location.country(),
//                            e.location.state(),
//                            e.location.city(),
//                            e.location.zip(),
//                            e.location.address(),
//                            e.location.distance()
//                    ));

                    return newVehicle;
                }).collect(Collectors.toList());

        String str= """
                id|make|model|body_style|exterior_color|vehicle_condition|year|mileage|price|mpg_city|mpg_highway
                """;
        System.out.println(str);
        List<NewVehicle> blue = newVehicles.stream()
                .filter(e -> null != e.getExterior_color())

//                    .filter(e -> "silver".equalsIgnoreCase(e.exterior_color))
//                   .filter(e -> e.vehicle_condition.equalsIgnoreCase("new"))
//                .peek(e -> {
//                    System.out.println(e.id);
//                })
//                .filter(e -> e.mileage !=null)
//                .filter(e -> e.mileage > 10 && e.mileage < 20)
//                .peek(e -> {
//                    System.out.println(e.id);
//                })
//                .map(e -> {
//                    NewVehicle nv = new NewVehicle();
//                    nv.setId(e.id);
//                    return nv;
//                })
//                .limit(10)

//                .forEach(e -> {
//
//                    System.out.println(e.id+"|"+e.make+"|"+e.model+"|"+e.body_style+"|"+ e.exterior_color+"|"+e.vehicle_condition+"|"+ e.year+"|"+e.mileage+"|"+ e.price+"|"+ e.mpg_city+"|"+e.mpg_highway);
//
//                });
                .limit(63)
                .collect(Collectors.toList());

        System.out.println(blue.size());
        NewVehicleWrapper wrapper = new NewVehicleWrapper();
        wrapper.setData(blue);
        System.out.println(mapper.writeValueAsString(wrapper));
    }
}
