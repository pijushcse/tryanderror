package com.example.datagenerator;

import lombok.Data;

import java.util.List;

@Data
public class NewVehicleWrapper {
    List<NewVehicle> data;
}
