package com.example.datagenerator;

public record DealerLocation() {
}
