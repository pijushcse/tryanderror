package com.example.datagenerator;

import lombok.Data;

import java.util.List;

@Data
public class NewVehicle {
    String id, make, model, body_style, exterior_color, vehicle_condition;
    Integer year, mileage, price;
    Dealer dealer;

    String imageUrl;
    List<String> specifications;
    List<String> features;

    record Dealer(String name, String country, String state, String city, String zip, String street, Integer distance) {
    }
}